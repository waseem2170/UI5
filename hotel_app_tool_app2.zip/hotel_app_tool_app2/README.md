## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Tue Jan 25 2022 19:24:53 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori|
|**App Generator Version**<br>1.4.6|
|**Generation Platform**<br>SAP Business Application Studio|
|**Floorplan Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://r36z.ucc.ovgu.de:443/sap/opu/odata/sap/ZSD_030_HOTEL_TOOL_SRV
|**Module Name**<br>hotel_app_tool_v4|
|**Application Title**<br>Hotel tool detail app|
|**Namespace**<br>be.ap.edu|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>Latest|
|**Enable Code Assist Libraries**<br>False|
|**Add Eslint configuration**<br>False|
|**Enable Telemetry**<br>True|

## hotel_app_tool_v4

A Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


