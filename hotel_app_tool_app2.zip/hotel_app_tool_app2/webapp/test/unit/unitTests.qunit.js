/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"beapedu/hotel_app_tool_v4/test/unit/AllTests"
	], function () {
		QUnit.start();
	});
});
