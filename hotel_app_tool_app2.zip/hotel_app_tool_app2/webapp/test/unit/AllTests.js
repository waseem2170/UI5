sap.ui.define([
	"beapedu/hotel_app_tool_v4/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
