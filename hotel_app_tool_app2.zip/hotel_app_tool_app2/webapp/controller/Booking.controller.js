sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
],

    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, JSONModel, History) {

        "use strict";

        return Controller.extend("be.ap.edu.hotelapptoolv4.controller.Booking", {

            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.getRoute("addBooking").attachPatternMatched(this._onObjectMatched, this);

                    const ojsonModel = new JSONModel(),
                    booking = {
                        "HotelId" : 0,
                        "Id":  0,
                        "Name" : "",
                        "Firstname" : "",
                        "Startdate" : "",
                        "Nights" : 0,
                        "Email" : ""
                            };
                ojsonModel.setProperty("/booking", booking);
                    this.getView().setModel(ojsonModel);
            },

            _onObjectMatched: function (oEvent) {
                //var sObjectId = oEvent.getParameter("arguments").sObjectId;
                //this._bindView("/bookingSet" + sObjectId)
                //this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");

            },

            onSavePressed: function () {
                let booking= this.getView().getModel().getProperty("/booking");
                booking.HotelId = parseInt(booking.HotelId);
                //booking.Startdate = this.byId("startdate").getDateValue().toJSON()
                booking.Startdate = "/Date(1651449600000)/";
                booking.Nights = parseInt(booking.Nights);
                const model =  this.getOwnerComponent().getModel();  
                console.log("Booking; " + booking);

                model.create("/bookingSet", booking,
                {
                    success:function(data) {
                        console.log(data)
                        MessageBox.show(
                            "Booking added!", {
                                icon: MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        )
                    },
                    error:function(data) {
                        console.log(data)
                        MessageBox.show(
                            "Couldn't add booking, try again later!", {
                                icon: MessageBox.Icon.ERROR,
                                title: "Error",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    },

                })
            },

            onNavBack: function () {
                window.history.go(-1);
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("hotelSet")
            },

            onCancelPressed: function(){
                window.history.go(-1);
                window.reload();
            },

            _bindView : function (sObjectPath) {
                var oViewModel = this.getOwnerComponent().getModel("addBooking");
    
                this.getView().bindElement({
                    path: sObjectPath,
                    events: {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function () {
                            oViewModel.setProperty("/busy", true);
                        },
                        dataReceived: function () {
                            oViewModel.setProperty("/busy", false);
                        }
                    }
                });
            },
    
            _onBindingChange : function () {
                var oView = this.getView(),
                    oViewModel = this.getModel("addBooking"),
                    oElementBinding = oView.getElementBinding();
    
                // No data for the binding
                if (!oElementBinding.getBoundContext()) {
                    this.getRouter().getTargets().display("objectNotFound");
                    return;
                }
    
                var oResourceBundle = this.getResourceBundle(),
                    oObject = oView.getBindingContext().getObject(),
                    sObjectId = oObject.Id,
                    sObjectName = oObject.BOOKSet;
    
                    oViewModel.setProperty("/busy", false);
                    oViewModel.setProperty("/shareSendEmailSubject",
                        oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
                    oViewModel.setProperty("/shareSendEmailMessage",
                        oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
            }

        });

    });