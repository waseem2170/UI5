sap.ui.define([
    "./BaseController",
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History"
],

    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, Controller) {

        "use strict";

        return BaseController.extend("be.ap.edu.hotelapptoolv4.controller.Description", {

            onInit: function () {
                
                var oRouter = this.getRouter();
			    oRouter.getRoute("updateDescription").attachPatternMatched(this._onRouteMatched, this);
            },

            onSave: function () {
                console.log("HERE: ")
                const updatedBooking = {
                    "HotelId" : 0,
                    "Id":  0,
                    "Name" : "",
                    "Firstname" : "",
                    "Startdate" : "",
                    "Nights" : 0,
                    "Email" : ""
                        };

                var getId = parseInt(this.getView().byId("bookId").getValue());
                console.log("save: " + getId)

                updatedBooking.HotelId = parseInt(this.byId("hotelId").getValue());
                updatedBooking.Id = parseInt(this.byId("bookId").getValue());
                updatedBooking.Name = this.byId("name").getValue();
                updatedBooking.Firstname = this.byId("firstname").getValue();
                updatedBooking.Startdate = "/Date(1651449600000)/";
                updatedBooking.Nights = parseInt(this.byId("nights").getValue());
                updatedBooking.Email = this.byId("email").getValue();
                console.log(updatedBooking)
                this.getOwnerComponent().getModel().update("/bookingSet("+getId+")", updatedBooking, {
                    success: function(data) {
                        console.log(data);
                        MessageBox.show(
                            "Booking updated", {
                                icon: MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    },
                    error: function(e) {
                        MessageBox.show(
                            "Couldn't update booking, try again later!", {
                                icon: MessageBox.Icon.ERROR,
                                title: "Error",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    }
                });
            },

            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
    
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteMain", true);
                }
            },

            _onObjectMatched: function (oEvent) {
            
                var sObjectId =  oEvent.getParameter("arguments").objectId;
                //this._bindView("/bookingSet" + sObjectId);
                this.getModel().metadataLoaded().then( function(){
    
                    var sObjectPath = this.getModel().createKey("hotelSet", { 
                        Id: sObjectId  
                    });
                    this._bindView(sObjectPath);
                }.bind(this));
                console.log("hotelID: " + sObjectId)
            },

            _onRouteMatched : function (oEvent) {
                var oArgs, oView;
                oArgs = oEvent.getParameter("arguments").objectId;
                oView = this.getView();
                console.log("ARGS: " + oArgs)
                oView.bindElement({
                    path : "/hotelSet(" + oArgs + ")",
                    events : {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function (oEvent) {
                            oView.setBusy(true);
                        },
                        dataReceived: function (oEvent) {
                            oView.setBusy(false);
                        }
                    }
                });
            },
            _onBindingChange : function (oEvent) {
                // No data for the binding
                if (!this.getView().getBindingContext()) {
                    this.getRouter().getTargets().display("notFound");
                }
            }
            
        });

    });