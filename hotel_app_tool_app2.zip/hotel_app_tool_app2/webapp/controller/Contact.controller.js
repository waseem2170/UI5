sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
],

    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, History) {

        "use strict";

        return Controller.extend("be.ap.edu.hotelapptoolv4.controller.Contact", {

            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.getRoute("addContact").attachPatternMatched(this._onObjectMatched, this);

                const ojsonModel = new JSONModel(),
                contact = {
                    "HotelId" : 0,
                    "Id":  0,
                    "Name" : "",
                    "Firstname" : "",
                    "Email" : ""
                        };
             ojsonModel.setProperty("/contact", contact);
                 this.getView().setModel(ojsonModel);
            },

            onSavePressed: function () {
                let contact= this.getView().getModel().getProperty("/contact");
                contact.HotelId = parseInt(contact.HotelId);
                const model =  this.getOwnerComponent().getModel();  
                console.log("Contact; " + contact);

                model.create("/contactSet", contact,
                {
                    success:function(data) {
                        console.log(data)
                    },
                    error:function(data) {
                        console.log(data)
                    },

                })
            },

            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
    
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteMain", true);
                }
            }

        });

    });