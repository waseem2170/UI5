sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, JSONModel) {
        "use strict";
/*
*
* Dit is gewoon een test controller waarmee ik de routing wou testen naar een speciefieke object ID
*
*
*/
        return BaseController.extend("be.ap.edu.hotelapptoolv4.controller.HotelDetail", {
            onInit: function () {
                var oViewModel = new JSONModel({

                    busy : true,

                    delay : 0

                });
                var oRouter = this.getRouter();
			    oRouter.getRoute("hotelDetail").attachPatternMatched(this._onRouteMatched, this);
            },

            _onObjectMatched: function (oEvent) {
            
                var sObjectId =  oEvent.getParameter("arguments").objectId;
                //this._bindView("/bookingSet" + sObjectId);
                this.getModel().metadataLoaded().then( function(){
    
                    var sObjectPath = this.getModel().createKey("hotelSet", { 
                        Id: sObjectId  
                    });
                    this._bindView(sObjectPath);
                }.bind(this));
                console.log("hotelID: " + sObjectId)
            },

            onUpdatePressed: function () {
                const updatedContact = {
                    "HotelId" : 0,
                    "Id":  0,
                    "Name" : "",
                    "Firstname" : "",
                    "Email" : ""
                        };

                var getId = parseInt(this.getView().byId("contactId").getValue());
                console.log("save: " + getId)

                updatedContact.HotelId = parseInt(this.byId("hotelId").getValue());
                updatedContact.Id = parseInt(this.byId("contactId").getValue());
                updatedContact.Name = this.byId("name").getValue();
                updatedContact.Firstname = this.byId("firstname").getValue();
                updatedContact.Email = this.byId("email").getValue();
                console.log(updatedContact)
                this.getOwnerComponent().getModel().update("/contactSet("+getId+")", updatedContact, {
                    success: function(data) {
                        console.log(data);
                        MessageBox.show(
                            "Contact updated", {
                                icon: MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    },
                    error: function(e) {
                        MessageBox.show(
                            "Couldn't update booking, try again later!", {
                                icon: MessageBox.Icon.ERROR,
                                title: "Error",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    }
                });

            },

            onAddbooking: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("addBooking")
            },
            onAddcontact: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("addContact")
            },
            onEditdescription: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("updateDescription")
            },
            onPressBooking: function (oEvent){
                this._showBooking(oEvent.getSource());
            },
            onPressContact:function (oEvent){
                this._showContact(oEvent.getSource());
            },
            onEditdescription: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("updateDescription")
                this._showHotel(oEvent.getSource());
            },
            
            _showBooking: function (oItem){
                this.getRouter().navTo("updateBooking", {
                    objectId: oItem.getBindingContext().getProperty("Id")
                });    

            },
            _showContact: function (oItem){
                this.getRouter().navTo("updateContact", {
                    objectId: oItem.getBindingContext().getProperty("Id")
                });    
            },
            _showHotel: function (oItem){
                this.getRouter().navTo("updateDescription", {
                    objectId: oItem.getBindingContext().getProperty("Id")
                });    
            },

            _onRouteMatched : function (oEvent) {
                var oArgs, oView;
                oArgs = oEvent.getParameter("arguments").objectId;
                oView = this.getView();
                console.log("ARGS: " + oArgs)
                oView.bindElement({
                    path : "/hotelSet(" + oArgs + ")",
                    events : {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function (oEvent) {
                            oView.setBusy(true);
                        },
                        dataReceived: function (oEvent) {
                            oView.setBusy(false);
                        }
                    }
                });
            },
            _onBindingChange : function (oEvent) {
                // No data for the binding
                if (!this.getView().getBindingContext()) {
                    this.getRouter().getTargets().display("notFound");
                }
            }
            
    
           
           
        });
    });

