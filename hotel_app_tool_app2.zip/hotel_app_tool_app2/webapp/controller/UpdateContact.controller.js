sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/core/routing/History"
],

    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, JSONModel, MessageBox, History) {

        "use strict";
        return BaseController.extend("be.ap.edu.hotelapptoolv4.controller.UpdateContact", {
            
            onInit: function () {

                var oViewModel = new JSONModel({

                    busy : true,

                    delay : 0

                });
                var oRouter = this.getRouter();
			    oRouter.getRoute("updateContact").attachPatternMatched(this._onRouteMatched, this);
                
                //this.getRouter().getRoute("updateBooking").attachPatternMatched(this._onObjectMatched, this);
                //this.setModel(oViewModel, "updateBooking");
            },

            _onObjectMatched: function (oEvent) {
            
                var sObjectId =  oEvent.getParameter("arguments").objectId;
                //this._bindView("/bookingSet" + sObjectId);
                this.getModel().metadataLoaded().then( function(){
    
                    var sObjectPath = this.getModel().createKey("contactSet", { 
                        Id: sObjectId  
                    });
                    this._bindView(sObjectPath);
                }.bind(this));
                console.log("Contact: " + sObjectId)
            },

            onUpdatePressed: function () {
                const updatedContact = {
                    "HotelId" : 0,
                    "Id":  0,
                    "Name" : "",
                    "Firstname" : "",
                    "Email" : ""
                        };

                var getId = parseInt(this.getView().byId("contactId").getValue());
                console.log("save: " + getId)

                updatedContact.HotelId = parseInt(this.byId("hotelId").getValue());
                updatedContact.Id = parseInt(this.byId("contactId").getValue());
                updatedContact.Name = this.byId("name").getValue();
                updatedContact.Firstname = this.byId("firstname").getValue();
                updatedContact.Email = this.byId("email").getValue();
                console.log(updatedContact)
                this.getOwnerComponent().getModel().update("/contactSet("+getId+")", updatedContact, {
                    success: function(data) {
                        console.log(data);
                        MessageBox.show(
                            "Contact updated", {
                                icon: MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    },
                    error: function(e) {
                        MessageBox.show(
                            "Couldn't update booking, try again later!", {
                                icon: MessageBox.Icon.ERROR,
                                title: "Error",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    }
                });

            },

            onNavBack: function () {     
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();
    
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("Main", true);
                }
            
            },

            onDeletePressed: function () {  
                 
                const model = this.getOwnerComponent().getModel();
                var getId = parseInt(this.getView().byId("contactId").getValue());
                model.remove("/contactSet("+getId+")", {
                    success: function(data) {
                        console.log(data);
                        MessageBox.show(
                            "Contact deleted", {
                                icon: MessageBox.Icon.INFORMATION,
                                title: "Information",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    },
                    error: function(e) {
                        MessageBox.show(
                            "Something went wrong, try again later!", {
                                icon: MessageBox.Icon.ERROR,
                                title: "Error",
                                actions: [MessageBox.Action.OK],
                                emphasizedAction: MessageBox.Action.YES,
                                onClose: function (oAction) { / * do something * / }
                            }
                        );
                    }
                });
            
            },

            onNavBack: function () {     
                    var oHistory = History.getInstance();
                    var sPreviousHash = oHistory.getPreviousHash();
        
                    if (sPreviousHash !== undefined) {
                        window.history.go(-1);
                    } else {
                        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                        oRouter.navTo("Main", true);
                    }
                
            },

            _onRouteMatched : function (oEvent) {
                var oArgs, oView;
                oArgs = oEvent.getParameter("arguments").objectId;
                oView = this.getView();
                console.log("ARGS: " + oArgs)
                oView.bindElement({
                    path : "/contactSet(" + oArgs + ")",
                    events : {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function (oEvent) {
                            oView.setBusy(true);
                        },
                        dataReceived: function (oEvent) {
                            oView.setBusy(false);
                        }
                    }
                });
            },
            _onBindingChange : function (oEvent) {
                // No data for the binding
                if (!this.getView().getBindingContext()) {
                    this.getRouter().getTargets().display("notFound");
                }
            }
            

            /*_bindView : function (sObjectPath) {
                var oViewModel = this.getModel("objectView");
    
                this.getView().bindElement({
                    path: sObjectPath,
                    events: {
                        change: this._onBindingChange.bind(this),
                        dataRequested: function () {
                            oViewModel.setProperty("/busy", true);
                        },
                        dataReceived: function () {
                            oViewModel.setProperty("/busy", false);
                        }
                    }
                });
            },

            _onBindingChange : function () {
                var oView = this.getView(),
                    oViewModel = this.getModel("objectView"),
                    oElementBinding = oView.getElementBinding();
                    console.log("oL: " + oElementBinding)

    
                // No data for the binding
                if (!oElementBinding.getBoundContext()) {
                    this.getRouter().getTargets().display("objectNotFound");
                    return;
                }
                console.log("ID bindChange: ")

    
                var oResourceBundle = this.getResourceBundle(),
                    oObject = oView.getBindingContext().getObject(),
                    sObjectId = oObject.Id,
                    sObjectName = oObject.bookingSet;
                    console.log("ID bindChange: " + sObjectId)
                    console.log("name bindChange: " + sObjectName)
    
                    oViewModel.setProperty("/busy", false);
                    oViewModel.setProperty("/shareSendEmailSubject",
                        oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
                    oViewModel.setProperty("/shareSendEmailMessage",
                        oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
            }*/

    
           
        });

    });