sap.ui.define([
    "./BaseController",

    "sap/ui/core/mvc/Controller",
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController) {
        "use strict";

        return BaseController.extend("be.ap.edu.hotelapptoolv4.controller.Main", {
            onInit: function () {
                /*var Model = this.getView().getModel(); 
                console.log("model: " + Model)
                var oView = this.getView();
                var oModel = this.getOwnerComponent().getModel();
                console.log("Omodel: " + oModel)*/
                
                //var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                //loRouter.navTo("hotelDetail/1")

                this.getRouter().navTo("hotelDetail", {
                    objectId: 1

                });   
               
                /* oModel.read("/hotelSet("+id+")", {
                    urlParameters: {
                        "$expand": "hotelBooking,hotelContact"
                    },
                    success: function(data, response) {
                        const jsonModel = new jsonModel();
                        jsonModel.setProperty("/hotel", data);
                        oView.setModel(jsonModel);
                        console.log("json: " + jsonModel);
                        
                    },
                    error: function(oError) {
                    }
                })*/


            },

            onAddbooking: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("addBooking")
            },
            onAddcontact: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("addContact")
            },
            onEditdescription: function (){
                var loRouter = sap.ui.core.UIComponent.getRouterFor(this);
                loRouter.navTo("updateDescription")
            },
            onPressBooking: function (oEvent){
                this._showBooking(oEvent.getSource());
            },
            onPressContact:function (oEvent){
                this._showContact(oEvent.getSource());
            },
            
            _showBooking: function (oItem){
                this.getRouter().navTo("updateBooking", {

                    objectId: oItem.getBindingContext().getProperty("Id")

                });    

            },
            _showContact: function (oItem){
                this.getRouter().navTo("updateContact", {
                    objectId: oItem.getBindingContext().getProperty("Id")

                });    
            },
            _showHotel: function (oItem){
                this.getRouter().navTo("updateDescription", {
                    objectId: oItem.getBindingContext().getProperty("Id")

                });    
            }
        });
    });
